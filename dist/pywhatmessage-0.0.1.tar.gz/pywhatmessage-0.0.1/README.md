# pywhatsapp
A module in which you can send whatsapp messages.
It is the same as pywhatkit, but there is a issue in it. I've modified it.
