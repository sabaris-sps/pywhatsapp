from pywhatsapp import sendwhatmsg_instantly
from pywhatsapp import sendwhatmsg
from pywhatsapp import sendwhatmsg_to_group
from pywhatsapp import sendwhatmsg_to_group_instantly
from pywhatsapp import sendwhats_image
from pywhatsapp import open_web
